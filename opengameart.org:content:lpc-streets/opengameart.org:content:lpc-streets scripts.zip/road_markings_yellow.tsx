<?xml version="1.0" encoding="UTF-8"?>
<tileset name="road_markings_yellow" tilewidth="32" tileheight="32" tilecount="132" columns="12">
 <image source="road_markings_yellow.png" width="384" height="352"/>
</tileset>
