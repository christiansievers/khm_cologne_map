<?xml version="1.0" encoding="UTF-8"?>
<tileset name="street_dark" tilewidth="32" tileheight="32" tilecount="24" columns="6">
 <image source="street_dark.png" width="192" height="128"/>
 <terraintypes>
  <terrain name="street" tile="0"/>
 </terraintypes>
 <tile id="0" terrain="0,0,0,0"/>
 <tile id="1" terrain="0,0,0,0"/>
 <tile id="2" terrain="0,0,0,0"/>
 <tile id="3" terrain="0,0,0,0"/>
 <tile id="4" terrain="0,0,0,0" probability="0.1"/>
 <tile id="5" terrain="0,0,0,0"/>
 <tile id="6" terrain="0,0,0,0"/>
 <tile id="7" terrain="0,0,0,0"/>
 <tile id="8" terrain="0,0,0,0"/>
 <tile id="9" terrain="0,0,0,0" probability="0.1"/>
 <tile id="11" terrain="0,0,0,0" probability="0.1"/>
 <tile id="12" terrain="0,0,0,0"/>
 <tile id="13" terrain="0,0,0,0"/>
 <tile id="14" terrain="0,0,0,0"/>
 <tile id="15" terrain="0,0,0,0"/>
 <tile id="16" terrain="0,0,0,0" probability="0.1"/>
 <tile id="17" terrain="0,0,0,0"/>
 <tile id="18" terrain="0,0,0,0" probability="0.1"/>
 <tile id="19" terrain="0,0,0,0" probability="0.1"/>
 <tile id="20" terrain="0,0,0,0" probability="0.1"/>
 <tile id="22" terrain="0,0,0,0" probability="2"/>
</tileset>
